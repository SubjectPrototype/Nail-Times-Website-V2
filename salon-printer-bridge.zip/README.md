# Nail Times Printer Bridge

This process runs on a Windows computer inside the salon network. It polls the hosted Nail Times API for receipt jobs and sends ESC/POS data to the Ethernet receipt printer.

## Setup

1. Copy `printer-bridge/.env.example` to `printer-bridge/.env`.
2. Set `BRIDGE_API_URL` to the real deployed backend URL, such as `https://your-service.onrender.com` (not the website/frontend URL).
3. Generate a long random value for `PRINT_BRIDGE_TOKEN` and use the same value in the deployed backend environment.
4. Keep `PRINTER_IP=10.0.0.101` and `PRINTER_PORT=9100` for the salon printer.
5. Start the bridge from the project root with `npm run printer-bridge`.

Keep that terminal window open. A queued job only prints while this bridge process is running. A successful startup shows the backend URL followed by `10.0.0.101:9100`; configuration and polling errors appear in the same window.

## Salon Computer Package

The salon computer does not need the full website project. Copy the packaged `salon-printer-bridge` folder to that computer, install Node.js LTS, and double-click `Start Printer Bridge.bat`. Keep its window open while direct printing is needed.

The confirmed printer is a GoCheckIn MHT-P80A with 80mm paper and an Ethernet connection on TCP port `9100`. The bridge sends standard ESC/POS receipt data directly to that socket.

## Network Test

Run this from the salon computer:

```powershell
Test-NetConnection 10.0.0.101 -Port 9100
```

`TcpTestSucceeded: True` confirms that the computer can reach the expected printer port.
